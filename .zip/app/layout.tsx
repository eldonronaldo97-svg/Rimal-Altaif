import "./globals.css";
import { Montserrat } from "next/font/google";
import FloatingCart from "@/components/FloatingCart";
import LayoutContent from "@/components/LayoutContent";
import InventoryProvider from "@/components/InventoryProvider";
import { IBM_Plex_Sans_Arabic } from "next/font/google";

import type { Metadata, Viewport } from "next";

const ibmArabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic"],
  weight: ["300", "400", "500", "700"],
  variable: "--font-arabic",
});

const montserrat = Montserrat({
  subsets: ["latin"],
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export const metadata: Metadata = {
  title: {
    default: "رمال الطائف | Rimal Altaif",
    template: "%s | رمال الطائف",
  },

  description:
    "رمال الطائف | Rimal Altaif - متجر عطور فاخرة وأصلية في مصر. اكتشف أفضل العطور الرجالية والنسائية وعطور للجنسين.",

  keywords: [
    "رمال الطائف",
    "Rimal Altaif",
    "عطور رمال الطائف",
    "عطور اصلية",
    "عطور فاخرة",
    "عطور رجالي",
    "عطور نسائي",
    "عطور للجنسين",
    "شراء عطور في مصر",
    "متجر عطور",
  ],

  metadataBase: new URL("https://rimalaltaif.com"),

  alternates: {
    canonical: "https://rimalaltaif.com",
  },

  openGraph: {
    title: "رمال الطائف | Rimal Altaif",
    description:
      "متجر رمال الطائف للعطور الفاخرة والأصلية في مصر. عطور رجالية ونسائية وعطور للجنسين.",
    url: "https://rimalaltaif.com",
    siteName: "رمال الطائف | Rimal Altaif",
    locale: "ar_EG",
    type: "website",
  },

  robots: {
    index: true,
    follow: true,

    googleBot: {
      index: true,
      follow: true,
    },
  },
};

/* =========================
   SEO STRUCTURED DATA
========================= */

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": "https://rimalaltaif.com/#organization",

  name: "رمال الطائف",
  alternateName: "Rimal Altaif",

  url: "https://rimalaltaif.com",

  logo: {
    "@type": "ImageObject",
    url: "https://rimalaltaif.com/logo.png",
  },
};

const websiteSchema = {
  "@context": "https://schema.org",
  "@type": "WebSite",
  name: "رمال الطائف",
  alternateName: "Rimal Altaif",
  url: "https://rimalaltaif.com",
  inLanguage: "ar-EG",
};

const INVENTORY_SOURCE_URL =
  "https://script.google.com/macros/s/AKfycbxHhrvzHZEvGfnhCwbH_e7IgF1ahwjm6VXfGKHjPsuC99PcU9dC5Hf59WK15CLIHCNO/exec?action=inventory";

async function getInitialInventory(): Promise<Record<string, number> | null> {
  try {
    const response = await fetch(INVENTORY_SOURCE_URL, {
      next: { revalidate: 15 },
      headers: { Accept: "application/json" },
    });
    if (!response.ok) return null;
    const data = await response.json();
    if (data?.success !== true || !Array.isArray(data.products)) return null;

    const quantities: Record<string, number> = {};
    for (const item of data.products) {
      const id = String(item?.id ?? "").trim();
      const quantity = Number(item?.quantity);
      if (id && Number.isFinite(quantity) && quantity >= 0) {
        quantities[id] = Math.floor(quantity);
      }
    }
    return quantities;
  } catch (error) {
    console.error("Could not load initial inventory:", error);
    return null;
  }
}

export default async function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const initialInventory = await getInitialInventory();
  return (
    <html lang="ar" dir="rtl">
      <body className={`${montserrat.className} ${ibmArabic.variable}`}>
        <InventoryProvider initialInventory={initialInventory}>
          {children}
          <FloatingCart />
          <LayoutContent />
        </InventoryProvider>

        {/* Google Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(organizationSchema).replace(
              /</g,
              "\\u003c"
            ),
          }}
        />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(websiteSchema).replace(
              /</g,
              "\\u003c"
            ),
          }}
        />
      </body>
    </html>
  );
}