const productData = [
  // 💎 DIAMOND COLLECTION
  {
    id: "M1",
    name: "Musk collection",
    brand: "Ibraq",
    size: "20ml",
    price: 4000,
    oldPrice: 5000,
    image: "/products/3e2d2c76-a107-4e33-8943-5d4b0f3cb2f1-1000x1000-12XwCUurtCS6OyiKmzyyXumP3PGJ4ZkOYIveZMxL.webp",
    category: "Unisex",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  {
    id: "d1",
    name: "Black Carbon Diamond",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/diamond-9.jpg",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d2",
    name: "White Regent Diamond",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/diamond-10.jpg",
    category: "Unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d3",
    name: "Sapphire Leather",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-1.jpg",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
  },
  {
    id: "d4",
    name: "Emerald Soul Diamond",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-2.jpg",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d5",
    name: "Purple Heart Diamond",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-3.jpg",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d6",
    name: "Grey Pearl Diamond",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-4.jpg",
    category: "Unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d7",
    name: "Black Diamond Incense",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-5.jpg",
    category: "Men",
    quantity: 4, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d8",
    name: "Pink Diamond Sakura",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-6.jpg",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d9",
    name: "Blue Diamond Aqua",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/tobacco-7.jpg",
    category: "Men",
    quantity: 4, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d10",
    name: "Nude Coral Diamond",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/diamond-0.jpg",
    category: "Unisex",
    quantity: 4, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  {
    id: "d11",
    name: "Cullinan Diamond Iris",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/fbcea5f6-6fb7-49ab-9b60-82fb3f6c0f61-1000x1000-tBHglJ1nRjhHY0cnHTd7tBmiQ539p6gNEjVbtlq2.webp",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "d12",
    name: "Balas rose",
    brand: "Ibraq",
    size: "150ml",
    price: 1450,
    oldPrice: 2250,
    image: "/products/76fbd974-eb5c-40c9-bf3f-dd4f8893097e-1000x1000-nQLajCJNkYiblOW9nbww9OPnZV1v5QsGZiEz7iUu.webp",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },

  // 🚬 TOBACCO COLLECTION
  {
    id: "t1",
    name: "Greek Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1499,
    oldPrice: 2350,
    image: "/products/diamond-1.jpg",
    category: "Unisex",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "t2",
    name: "Jamaican Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1450,
    oldPrice: 2350,
    image: "/products/diamond-2.jpg",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
  },
  {
    id: "t3",
    name: "Mexican Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1499,
    oldPrice: 2350,
    image: "/products/diamond-3.jpg",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "t4",
    name: "Brazilian Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1450,
    oldPrice: 2350,
    image: "/products/diamond-4.jpg",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "t5",
    name: "Dominican Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1450,
    oldPrice: 2350,
    image: "/products/diamond-5.jpg",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "t6",
    name: "Spanish Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1499,
    oldPrice: 2350,
    image: "/products/diamond-6.jpg",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  {
    id: "t7",
    name: "French Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1450,
    oldPrice: 2350,
    image: "/products/diamond-8.jpg",
    category: "Unisex",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "t8",
    name: "Cuban Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1499,
    oldPrice: 2350,
    image: "/products/diamond-7.jpg",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
  },
  {
    id: "t9",
    name: "Tobacco Collection",
    brand: "Ibraq",
    size: "20ml",
    price: 2599,
    oldPrice: 3200,
    image: "/products/f87d28b1-5c25-4f5c-8014-b8486955e435-1000x1000-2c6V4LTKTgxO5Gr0ojghAAHleOZjVgqKTzSFMESy.webp",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  {
    id: "t10",
    name: "Arabian Tobacco",
    brand: "Ibraq",
    size: "100ml",
    price: 1499,
    oldPrice: 2350,
    image: "/products/63eb8a84-f43a-4963-b4c5-3cc6b5cc9028-1000x1000-15XAIUTT2eTTNsBaS17x8PZuL5YdEIp6oyzB9s08.webp",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
   // Assaf Main Collection
 
  {
    id: "a53",
    name: "Miss Arrogate Diva",
    brand: "Assaf",
    size: "150ml",
    category: "Women",
    quantity: 9, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1899,
    image: "/products/assaf/564d87f1-9467-47d7-8bbd-4dbbf6475568_900x900.webp",
    addedAt: "2026-08-20",
  }, 
  {
    id: "a52",
    name: "Addict Blue",
    brand: "Assaf",
    size: "125ml",
    category: "Men",
    quantity: 15, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    image: "/products/assaf/276c6eef-282e-4848-bf1d-3fcde0dbe6bf-1000x1000-Rbql80At7hh3Di1kfbtJopQMtZB7nKn0niQfJHiJ.webp",
    addedAt: "2026-08-22",
  }, 
  {
    id: "a51",
    name: "Boom Blue",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1899,
    image: "/products/assaf/1c668420-3d0d-44fa-84de-12f04e8394b9-1000x1000-oXNN7qa4ibbLe0HRGt6AB4QIO0IBba2B2ySHyGdH.webp",
    addedAt: "2026-08-24",
  }, 
  {
    id: "a50",
    name: "Hook Blue",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1899,
    image: "/products/assaf/72a0e83c-cd06-4943-8e86-c6ac5c7ffff3_900x900.webp",
    addedAt: "2026-08-23",
  },
  {
    id: "a48",
    name: "Wild Colt Boss",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1899,
    image: "/products/assaf/40435517-58c7-444a-87f3-0a4c96b6fd87_900x900.webp",
    addedAt: "2026-08-25",
  },
  {
    id: "a47",
    name: "Arrogate Pink Diva",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 6, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1899,
    image: "/products/assaf/11ad4cc6-f11a-464d-8792-100eacda5ce2-1000x1000-djNIw25Xy4lXP8woZVGWzWXCPSINNJT4yO7qXuxj.webp",
    addedAt: "2026-08-21",
  },
  {
    id: "a1",
    name: "Arrogate Addict Elixir",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2050,
    oldPrice: 2450,
    image: "/products/assaf/Arrogate_Addict_Elixir.jpg",
    addedAt: "2026-08-27",
  },

  {
    id: "a2",
    name: "Arrogate Blue De",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    oldPrice: 2650,
    image: "/products/assaf/5739d338-1a1e-4028-8eaa-1cf6d0e37a49-1000x1000-q06brKaZHFVpwXjRlSyoqrdxNWOv1f2lXHWXa72S.webp",
    addedAt: "2026-10-13",
  },

  {
    id: "a3",
    name: "Arrogate Comete",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1999,
    oldPrice: 2350,
    image: "/products/assaf/20cdc0d4-8a66-403d-8d72-32abbed52f6a-1000x1000-bEhkMClj3g8oKK6sg48ysLWHFSdRa3KBv7AUbfa0.webp",
  },

  {
    id: "a4",
    name: "Arrogate Euphoria",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1999,
    image: "/products/assaf/Arrogate_Euphoria.jpg",
  },

  {
    id: "a5",
    name: "Arrogate Addict",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    image: "/products/assaf/585d44d3-a3b5-40e6-b160-ef8ed1950763-912.16216216216x1000-82laPuOKhRNwO9faWWUxbMSuEDmc7mf4isKE7Uvl.webp",
    addedAt: "2026-10-14",
  },

  {
    id: "a6",
    name: "Arrogate Girl",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1999,
    image: "/products/assaf/77cb254f-ec2b-4622-9f51-c6ef288b9962-912.16216216216x1000-Thn2gsgHVR2CCE80qp3hvRupJgWQQYetzqeFOkSs.webp",
  },

  {
    id: "a7",
    name: "Arrogate Pink",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    bestSeller: true,
    price: 1999,
    oldPrice: 2650,
    image: "/products/assaf/e695d0ab-6f74-4d98-8655-e237af403967-1000x1000-ZZC45Zi1sxV09e2maCd3yrlrqHE7aQ3ejk19ws4F.webp",
    addedAt: "2026-08-27",
  },

  {
    id: "a8",
    name: "Arrogate Pink Rose",
    brand: "Assaf",
    size: "150ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2000,
    oldPrice: 2350,
    image: "/products/assaf/arrogate-pink-rose.jpg",
  },

  {
    id: "a9",
    name: "Attacks",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2000,
    oldPrice: 2350,
    image: "/products/assaf/attacks.jpg",
  },

  {
    id: "a10",
    name: "Bakhur Collection Box",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 3900,
    oldPrice: 4400,
    image: "/products/assaf/Bakhur_Collection_Box.jpg",
  },

  {
    id: "a11",
    name: "Challenge",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1900,
    image: "/products/assaf/Challenge.jpg",
  },

  {
    id: "a12",
    name: "Crown Spirit",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/Crown_Spirit.jpg",
  },

  {
    id: "a13",
    name: "Dangerous Arrogate",
    brand: "Assaf",
    size: "200ml",
    category: "unisex",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1850,
    image: "/products/assaf/49d675dd-1440-4a8c-9a92-82f8da9e0904-1000x1000-W4GzTiNnGQvYBHUGVCG7yftW28Kcxr0xQxlRlvKN.webp",
  },

  {
    id: "a14",
    name: "First Night",
    brand: "Assaf",
    size: "150ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2000,
    image: "/products/assaf/First_Night.jpg",
  },

  {
    id: "a15",
    name: "Frankel Black Elixir",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1999,
    image: "/products/assaf/Frankel_Black_Elixir.jpg",
  },

  {
    id: "a16",
    name: "Frankel Blue Elixir",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    image: "/products/assaf/Frankel_Blue_Elixir.jpg",
  },

  {
    id: "a17",
    name: "Frankel Storm",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1250,
    image: "/products/assaf/Frankel_Storm.jpg",
  },

  {
    id: "a18",
    name: "Frankel Imagination",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/frankel-imagination.jpg",
  },

  {
    id: "a19",
    name: "Frankel Silver Elixir",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    image: "/products/assaf/frankel-silver-elixir.jpg",
  },

  {
    id: "a20",
    name: "Glitch",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    image: "/products/assaf/glitch.jpg",
  },

  {
    id: "a21",
    name: "Gris Erik",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1750,
    image: "/products/assaf/Gris_Erik.jpg",
  },

  {
    id: "a22",
    name: "Lady",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/lady.jpg",
  },

  {
    id: "a23",
    name: "Lip Stick",
    brand: "Assaf",
    size: "150ml",
    category: "Women",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
    price: 1850,
    image: "/products/assaf/Lip_Stick.jpg",
  },

  {
    id: "a24",
    name: "Miss Arrogate",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1999,
    image: "/products/assaf/a2b0fe3e-daee-4ad8-922c-02ac53635e2e-1000x1000-eILLANmgQ7suG7WnmnA1FZM4J4vIbq6KGrlRrpf5.webp",
  },

  {
    id: "a25",
    name: "Miss Gris Dance",
    brand: "Assaf",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/Miss_Gris_Dance.jpg",
  },

  {
    id: "a26",
    name: "Miss Flora",
    brand: "Assaf",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1250,
    image: "/products/assaf/miss-flora.jpg",
  },

  {
    id: "a27",
    name: "Miss Gris Intense",
    brand: "Assaf",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/miss-gris-intense.jpg",
  },

  {
    id: "a28",
    name: "No Comment",
    brand: "Assaf",
    size: "100ml",
    category: "unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/no-comment.jpg",
  },

  {
    id: "a29",
    name: "Oud Bakhur",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2100,
    image: "/products/assaf/oud-bakhur.jpg",
  },

  {
    id: "a30",
    name: "Pegasus Proino",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1750,
    image: "/products/assaf/Pegasus_Proino.jpg",
  },

  {
    id: "a31",
    name: "Pegasus Aura",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1850,
    image: "/products/assaf/pegasus-aura.jpg",
  },

  {
    id: "a32",
    name: "Pegasus Bakhoor",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1750,
    image: "/products/assaf/pegasus-bakhoor.jpg",
  },

  {
    id: "a33",
    name: "Pink Lady",
    brand: "Assaf",
    size: "100ml",
    category: "Women",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1150,
    image: "/products/assaf/Pink_Lady.jpg",
  },

  {
    id: "a34",
    name: "Pink Queen",
    brand: "Assaf",
    size: "200ml",
    category: "Women",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1850,
    image: "/products/assaf/Pink_Queen.jpg",
  },

  {
    id: "a35",
    name: "strike black",
    brand: "Assaf",
    size: "125ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
    price: 1999,
    image: "/products/assaf/strike-black-assaf-arrogate-150ml.jpg",
  },

  {
    id: "a36",
    name: "Risk Comete",
    brand: "Assaf",
    size: "150ml",
    category: "unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1999,
    image: "/products/assaf/risk-comete.jpg",
  },

  {
    id: "a37",
    name: "Tobacco Black 40",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/tobacco-black-40.jpg",
  },

  {
    id: "a38",
    name: "Tobacco Jam 50",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/tobacco-jam-50.jpg",
  },

  {
    id: "a39",
    name: "Tobacco Rage 32",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/tobacco-rage-32.jpg",
  },

  {
    id: "a40",
    name: "Troy Enable",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1499,
    image: "/products/assaf/Troy_Enable.jpg",
  },

  {
    id: "a41",
    name: "Wild Colt elixir",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 4, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1999,
    image: "/products/assaf/4863d319-163b-4afb-81b4-67f6ed6a5e3d-1000x1000-cJqgWVHFKL6m2wFJq3BqKFZLCajAGtFkke8Bn6ce.webp",
  },

  {
    id: "a42",
    name: "Wild Colt Tobacco",
    brand: "Assaf",
    size: "200ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/Wild_Colt_Tobacco.jpg",
  },

  {
    id: "a43",
    name: "Wild Pegasus",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1750,
    image: "/products/assaf/Wild_Pegasus.jpg",
  },

  {
    id: "a44",
    name: "Wild Colt Bakhur",
    brand: "Assaf",
    size: "150ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1850,
    image: "/products/assaf/wild-colt-bakhur.jpg",
  },
{
    id: "a45",
    name: "Frankel Elixer Intense",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1150,
    image: "/products/assaf/Frankel Elixer.webp",
  },
  {
    id: "a46",
    name: "Frankel Afternoon",
    brand: "Assaf",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1350,
    image: "/products/assaf/FrankelAfterNoon.webp",
  },
  {
    "id": "dk1",
    "name": "Balqees",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Balqees.jpg",
    "category": "Women",
    "stock": false
  },
  {
    "id": "dk2",
    "name": "Sapphire",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Sapphire.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk3",
    "name": "Dkhoon Oud",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Dkhoon_Oud.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk4",
    "name": "Khayal",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Khayal.jpg",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk5",
    "name": "Dubai",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Dubai.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk6",
    "name": "Doha Skyline",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Doha_Skyline.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk7",
    "name": "Muscat",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Muscat.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk8",
    "name": "AbuDhabi",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/AbuDhabi.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk9",
    "name": "Signature Gold",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Signature_Gold.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk10",
    "name": "Signature Black",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Signature_Black.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk11",
    "name": "Signature White",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Signature_white.jpg",
    "category": "Men",
    "stock": true
  },
  {
    "id": "dk12",
    "name": "Signature Silver",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Signature_Silver.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk13",
    "name": "Shiny",
    "brand": "Dkhoon",
    quantity: 1,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Shiny.jpg",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk14",
    "name": "Dkhoon Desert",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1499,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Dkhoon_Desert.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk15",
    "name": "Couture",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Couture.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk16",
    "name": "No One",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/No_One.jpg",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk17",
    "name": "Dkhoon Rose",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1499,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Dkhoon_Rose.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk18",
    "name": "Aura",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Aura.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk19",
    "name": "Tiamo",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Tiamo.jpg",
    "category": "Women",
    "stock": false
  },
  {
    "id": "dk20",
    "name": "Dkhoon Amber",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1499,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Dkhoon_Amber.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk21",
    "name": "Haneet",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Haneet.jpg",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk22",
    "name": "Khaylan",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1399,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Khaylan.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk23",
    "name": "Dkhoon Leather",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1499,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Dkhoon_Leather.jpg",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk24",
    "name": "Crown Black",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Crown_Black.jpg",
    "category": "Men",
    "stock": true
  },
  {
    "id": "dk25",
    "name": "Khalifa",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Khalifa.jpg",
    "category": "Men",
    "stock": false
  },
  {
    "id": "dk26",
    "name": "Zayed",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/Zayed.jpg",
    "category": "Men",
    "stock": true
  },
  {
    "id": "dk27",
    "name": "So Sweety",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/So_Sweety.jpg",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk29",
    "name": "Signature rose gold",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1499,
    "oldPrice": 2000,
    "image": "/products/dkhoon/4be38dc1-d258-4e45-af4e-64514d3e669d-thumbnail-770x770.webp",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk30",
    "name": "private 2 december",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/2894815c-8745-49d2-a1d4-c101bcbaff2a.webp",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk31",
    "name": "vanilla wood",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1450,
    "oldPrice": 2000,
    "image": "/products/dkhoon/d9a84d7d-64eb-48c6-b9a6-5c4574be1e0a.webp",
    "category": "Unisex",
    "stock": false
  },
  {
    "id": "dk32",
    "name": "Dkhoon queen",
    "brand": "Dkhoon",
    quantity: 0,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/1000163849.webp",
    "category": "Women",
    "stock": false
  },
  {
    "id": "dk33",
    "name": "Dkhoon solo",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/5210b6bb-b5a7-4327-bd4c-98ec3f8ecda5.avif",
    "category": "Women",
    "stock": true
  },
  {
    "id": "dk34",
    "name": "Dkhoon blue",
    "brand": "Dkhoon",
    quantity: 1,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/3898eaee-23f1-4cfc-a4a7-028959b0c7cb.webp",
    "category": "Unisex",
    "stock": true
  },
  {
    "id": "dk35",
    "name": "gold tears",
    "brand": "Dkhoon",
    quantity: 2,
    "size": "100ml",
     "price": 1350,
    "oldPrice": 2000,
    "image": "/products/dkhoon/fe487de0-8501-4262-9e82-0e557ad580d8.webp",
    "category": "Unisex",
    "stock": true
  },
  {
    id: "L1",
    name: "Fakhar Black",
    brand: "Lattafa",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1350,
    oldPrice: 1650,
    image: "/products/fakhar-black-lattafa.jpg",
  },
  {
    id: "L2",
    name: "Khamrah",
    brand: "Lattafa",
    size: "100ml",
    category: "Unisex",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1250,
    oldPrice: 1750,
    image: "/products/khamrah-lattafa.jpg",
  },
  {
    id: "L3",
    name: "Fakhar Gold",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1350,
    oldPrice: 1650,
    image: "/products/fakhar-gold-lattafa.jpg",
  },
  {
    id: "L4",
    name: "Teriaq",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1500,
    oldPrice: 1850,
    image: "/products/teriaq-lattafa.jpg",
  },
  {
    id: "L5",
    name: "Yara",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1050,
    oldPrice: 1500,
    image: "/products/yara-lattafa.jpg",
  },
  {
    id: "L6",
    name: "Khamrah Qahwa",
    brand: "Lattafa",
    size: "100ml",
    category: "Unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1250,
    oldPrice: 1750,
    image: "/products/khamrah-qahwa-lattafa.jpg",
  },
  {
    id: "L7",
    name: "Asad Zanzibar",
    brand: "Lattafa",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1250,
    oldPrice: 1500,
    image: "/products/asad-zanzibar-lattafa.jpg",
  },
  {
    id: "L8",
    name: "Asad",
    brand: "Lattafa",
    size: "100ml",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1100,
    oldPrice: 1500,
    image: "/products/asad-lattafa.jpg",
  },
  {
    id: "L9",
    name: "Ramz",
    brand: "Lattafa",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 900,
    image: "/products/ramz-lattafa.jpg",
  },
  {
    id: "L10",
    name: "Asad Elixir",
    brand: "Lattafa",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1100,
    oldPrice: 1500,
    image: "/products/asad-elixir-lattafa.jpg",
  },
  {
    id: "L11",
    name: "Eclaire",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1350,
    oldPrice: 1750,
    image: "/products/eclaire-lattafa.jpg",
  },
  {
    id: "L12",
    name: "Yara Elixer",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1150,
    image: "/products/yara-moi-lattafa.jpg",
  },
  {
    id: "L13",
    name: "Raghba",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 850,
    image: "/products/ragba_sheikh.jpg",
  },
  {
    id: "L14",
    name: "Opulent Dubai",
    brand: "Lattafa",
    size: "100ml",
    category: "Unisex",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 899,
    image: "/products/81um4vm8mOL._AC_UF894,1000_QL80_.jpg",
  },
  {
    id: "L15",
    name: "Angham",
    brand: "Lattafa",
    size: "100ml",
    category: "Women",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1199,
    image: "/products/81RDRroz8gL.jpg",
  },
  {
    id: "A3",
    name: "Rare Reef",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 4, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1599,
    oldPrice: 2300,
    image: "/products/rare-reef-afnan.jpg",
  },
  {
    id: "A4",
    name: "Supremacy Collectors Edition",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2799,
    oldPrice: 3650,
    image: "/products/supremacy-collectors-edition-afnan.jpg",
  },
  {
    id: "A5",
    name: "Supremacy Not Only Intense",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 2350,
    image: "/products/supremacy-not-only-intense-afnan.jpg",
  },
  {
    id: "A6",
    name: "Turathi Blue",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1899,
    oldPrice: 2400,
    image: "/products/turathi-blue-afnan.jpg",
  },
  {
    id: "A7",
    name: "Turathi Electric",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1899,
    oldPrice: 2400,
    image: "/products/turathi-electric-afnan.jpg",
  },
  {
    id: "A9",
    name: "9AM Pour Femme",
    brand: "Afnan",
    size: "100ml",
    category: "Women",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1650,
    oldPrice: 2200,
    image: "/products/9am-pour-femme-afnan.jpg",
  },
  {
    id: "A10",
    name: "9AM Dive",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1650,
    oldPrice: 2200,
    image: "/products/9am-dive-afnan.jpg",
  },
  {
    id: "A11",
    name: "9PM Elixir",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    price: 1650,
    oldPrice: 2200,
    image: "/products/9pm-elixir-afnan.jpg",
  },
  {
    id: "A12",
    name: "9PM Classic",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1650,
    oldPrice: 2200,
    image: "/products/9pm-afnan-classic.jpg",
  },
  {
    id: "A2",
    name: "9PM nightout",
    brand: "Afnan",
    size: "100ml",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    bestSeller: true,
    price: 1550,
    oldPrice: 2200,
    image: "/products/9pm-nightout-afnan.jpg",
  },
  {
    id: "A8",
    name: "9PM Rebel",
    brand: "Afnan",
    size: "100ml",
    category: "Unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1550,
    oldPrice: 2200,
    image: "/products/9pm-rebel-afnan.jpg",
  },
  {
    id: "a35",
    name: "Rebel Enable",
    brand: "Assaf",
    size: "150ml",
    category: "unisex",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: false,
    price: 1800,
    image: "/products/assaf/Rebel_Enable.jpg",
  },
  // 💎 HAWAS COLLECTION
  {
    id: "H4",
    name: "Hawas Elixir",
    brand: "RASASI",
    size: "100ml",
    price: 1500,
    oldPrice: 2000,
    image: "/products/Untitled-1_c44241f2-02f3-4bb1-afd0-26e04ab231f4.webp",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "H3",
    name: "Hawas Kobra",
    brand: "RASASI",
    size: "100ml",
    price: 1500,
    oldPrice: 2000,
    image: "/products/o.112706.jpg",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "H2",
    name: "Hawas Malibu",
    brand: "RASASI",
    size: "100ml",
    price: 1500,
    oldPrice: 2000,
    image: "/products/hawas-malibu-prod-duplicado-m7ti-7561.webp",
    category: "Men",
    quantity: 2, // أدخل عدد القطع المتاحة هنا
    stock: true,
  },
  {
    id: "H1",
    name: "Hawas Ice",
    brand: "RASASI",
    size: "100ml",
    price: 1499,
    oldPrice: 2200,
    image: "/products/61hDO6ICiyL.jpg",
    category: "Men",
    quantity: 10, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },

   // 💎 Offer COLLECTION
   {
    id: "o1",
    name: "Miss diva + Addict blue",
    brand: "Assaf",
    size: "275ml",
    price: 3499,
    oldPrice: 3999,
    image: "/products/زجاجتا عطر أنيقتان باللونين الأزرق والوردي.png",
    category: "Unisex",
    quantity: 9, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  {
    id: "o2",
    name: "Any Diamound + Hawas Ice",
    brand: "RIMAL ALTAIF",
    size: "250ml",
    price: 2799,
    oldPrice: 3350,
    image: "/products/عطر هاواس آيس ومجموعة الألماس、】【.png",
    category: "Men",
    quantity: 10, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  {
    id: "o3",
    name: "Any Tobacco + White Heart",
    brand: "RIMAL ALTAIF",
    size: "200ml",
    price: 1999,
    oldPrice: 2500,
    image: "/products/عطر القلب الأبيض ومجموعة التبغ الملونة.png",
    category: "Unisex",
    quantity: 6, // أدخل عدد القطع المتاحة هنا
    stock: true,
    bestSeller: true,
  },
  // 💎 mix COLLECTION
  {
    id: "m1",
    name: "Mira Amour",
    brand: "Le Bonheur",
    size: "100ml",
    price: 1750,
    oldPrice: 2300,
    image: "/products/mira-amour-100ml-eau-de-parfum-le-bonheur.webp",
    category: "Wonen",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m2",
    name: "Reine d'Or Cleo",
    brand: "Le Bonheur",
    size: "100ml",
    price: 1750,
    oldPrice: 2300,
    image: "/products/s-l1600 (4).webp",
    category: "Women",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m3",
    name: "HAYBA Royalty",
    brand: "Le Falcone",
    size: "100ml",
    price: 1400,
    oldPrice: 1900,
    image: "/products/Screenshot2026-02-10at5.28.47PM.webp",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m4",
    name: "HAYBA Majesty",
    brand: "Le Falcone",
    size: "100ml",
    price: 1400,
    oldPrice: 1900,
    image: "/products/Le-Falcone-Niche-Hayba-Majesty-eau-de-parfum-100ml-3.webp",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m5",
    name: "Mirsaal Valentine",
    brand: "Le Falcone",
    size: "100ml",
    price: 1400,
    oldPrice: 1900,
    image: "/products/Le-Falcone-Niche-Mirsaal-Valentine-eau-de-parfum-100ml-2.webp",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m6",
    name: "ASHA'A BLANC",
    brand: "ARABIYAT PRESTIGE",
    size: "110ml",
    price: 1400,
    oldPrice: 1900,
    image: "/products/Screenshot 2026-08-16 024313.png",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m7",
    name: "Qissat Al Najah Kiamichi",
    brand: "ARABIYAT PRESTIGE",
    size: "100ml",
    price: 1750,
    oldPrice: 2400,
    image: "/products/WHITE-BG_c7b2df8a-2516-48c0-a178-3c309480d6b3_800x.webp",
    category: "Men",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m8",
    name: "Mouda High End",
    brand: "ARABIYAT PRESTIGE",
    size: "100ml",
    price: 1850,
    oldPrice: 2400,
    image: "/products/parfum-arabiyat-prestige-mouda-high-end-edp-100ml-uniseks-6a43ef14558ae.webp",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m9",
    name: "Aariz",
    brand: "ARABIYAT PRESTIGE",
    size: "100ml",
    price: 1850,
    oldPrice: 2400,
    image: "/products/clx6rz0430vya01gi8r4ie2xv_pikaso_enhance__none_2K_Standard_r_c___3_.jpeg",
    category: "Unisex",
    quantity: 1, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-20",
  },
  {
    id: "m10",
    name: "Tuwaiq",
    brand: "ALMAS",
    size: "100ml",
    price: 1075,
    oldPrice: 1500,
    image: "/products/675dc48e-2825-4eab-a7e5-f9811f4a53fc-1000x1000-AqHoCgiQJMQfJs8cSEwJrOGYEhEVdSHKO9bimVDX.webp",
    category: "Men",
    quantity: 0, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-08-30",
  },
  {
    id: "m11",
    name: "قلب ابيض",
    brand: "ALMAS",
    size: "100ml",
    price: 699,
    oldPrice: 999,
    image: "/products/image.jpg",
    category: "Men",
    quantity: 6, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-10-7",
  },
  {
    id: "m12",
    name: "AURA",
    brand: "ALMAS",
    size: "100ml",
    price: 850,
    oldPrice: 999,
    image: "/products/22bc307f-500a-4fed-a7ac-85e32939767a.webp",
    category: "Men",
    quantity: 6, // أدخل عدد القطع المتاحة هنا
    stock: true,
    addedAt: "2026-10-17",
  },
  ];

// المخزون الرقمي هو المصدر الأساسي للتوفر؛ غيّر quantity لكل منتج فقط.
export const products = productData.map((product) => ({
  ...product,
  stock: Number(product.quantity ?? 0) > 0,
}));

export const homeBestSellers = [
  "o1", // Miss diva + Addict blue
  "o2", // Any Diamound + Hawas Ice
  "o3", // Any Tobacco + White Heart
  "t9", // Tobacco Collection
  "H1", // Hawas Ice
  "a53", // Miss Arrogate Diva
  "a52", // Addict Blue
  "M1", // musk collection
  "A2", // 9PM nightout
  "a35",  // strike black
  "a23", // lip stick
  "H1",  // Hawas Ice
  "d10", // Nude Coral Diamond
  "t6",  // Spanish Tobacco
  "dk17",  // dkhoon rose
];
